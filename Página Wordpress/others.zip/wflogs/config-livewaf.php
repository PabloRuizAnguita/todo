<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:2:{s:4:"cron";a:3:{i:0;O:24:"wfWAFCronFetchRulesEvent":1:{s:11:" * fireTime";i:1593107184;}i:1;O:25:"wfWAFCronFetchIPListEvent":1:{s:11:" * fireTime";i:1592849196;}i:2;O:36:"wfWAFCronFetchBlacklistPrefixesEvent":1:{s:11:" * fireTime";i:1592829800;}}s:20:"whitelistedURLParams";a:1:{s:77:"L3dwLWFkbWluL29wdGlvbnMtZ2VuZXJhbC5waHA=|cmVxdWVzdC5ib2R5W3dpZGdldF9jb2RlXQ==";a:1:{i:9;a:5:{s:9:"timestamp";i:1589622521;s:11:"description";s:28:"Whitelisted via Live Traffic";s:6:"source";s:12:"live-traffic";s:2:"ip";s:13:"81.44.106.140";s:6:"userID";i:2;}}}}