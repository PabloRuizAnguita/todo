=== Savona Lite ===

Contributors: Aslam optimathemes.com
Requires at least: WordPress 4.7+
Tested up to: WordPress 4.7
Version: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.en.html
Tags: blog, one-column, two-columns, right-sidebar, custom-menu, custom-logo, featured-images, footer-widgets, theme-options

== Copyright ==

Savona Lite, Copyright 2018 optimathemes.com
It is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Savona Lite uses the following third-party resources:

Screenshot image, Copyright Pixabay
License: CC0 1.0 Universal (CC0 1.0)
Source: https://www.pexels.com/photo/beige-and-black-chair-in-front-of-white-desk-509922/


== Changelog ==

= 1.0.0 =
* Initial release