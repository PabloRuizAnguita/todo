<?php

get_header();
?>
    
    <div id="primary" class="content-area">
        <?php echo apply_filters( 'zakra_after_primary_start_filter', false ); // WPCS: XSS OK. ?>

        <?php
        while ( have_posts() ) : the_post(); ?>

            <h1><?php the_field('name'); ?></h1>
            <?php if ( get_field( 'image') ) { ?>
            <img src="<?php the_field( 'image' ); ?>" />
                </br> 
            <?php } ?>

            <?php $name = get_field( 'name' ); ?>
                <?php if ( $name ) { ?>
                    <b> Nombre: </b> <?php the_field('name'); ?>
                    </br> 
            <?php } ?>

             <?php $author = get_field( 'author' ); ?>
                <?php if ( $author ) { ?>
                    <b> Autor: </b> <?php the_field('author'); ?>
                    </br> 
                <?php } ?>

            <?php $formula = get_field( 'formula' ); ?>
                <?php if ( $formula ) { ?>
                <b> Fórmula química: </b> <?php the_field('formula'); ?>
                </br> 
            <?php } ?>

            <?php $date = get_field( 'date' ); ?>
                <?php if ( $date ) { ?>
                    <b> Fecha: </b> <?php the_field('date'); ?>
                    </br> 
            <?php } ?>

            <?php $description = get_field( 'description' ); ?>
                <?php if ( $description ) { ?>
                    <b> Descripción: </b> <?php the_field('description'); ?>
                    </br> 
            <?php } ?>

            <?php the_content(); ?>
        

            <?php //Esto es para que se muestre el enlace de la entrada siguiente
                do_action( 'zakra_after_single_post_content' ); ?> 

           <?php  // If comments are open or we have at least one comment, load up the comment template.
            if ( comments_open() || get_comments_number() ) :
                comments_template();
            endif; ?>

        <?php endwhile; // End of the loop.
        ?>

        <?php echo apply_filters( 'zakra_after_primary_end_filter', false ); // // WPCS: XSS OK. ?>
    </div><!-- #primary -->

<?php
get_sidebar();
get_footer();