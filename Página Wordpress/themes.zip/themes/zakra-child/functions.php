<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );

if ( !function_exists( 'chld_thm_cfg_parent_css' ) ):
    function chld_thm_cfg_parent_css() {
        wp_enqueue_style( 'chld_thm_cfg_parent', trailingslashit( get_template_directory_uri() ) . 'style.css', array(  ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'chld_thm_cfg_parent_css', 10 );

// END ENQUEUE PARENT ACTION

function coleccion_post() {
  $labels = array(
    'name'               => _x( 'Coleccion', 'post type general name' ),
    'singular_name'      => _x( 'Coleccion', 'post type singular name' ),
    'add_new'            => _x( 'Add New', 'coleccion' ),
    'add_new_item'       => __( 'Add New Collection' ),
    'edit_item'          => __( 'Edit Collection' ),
    'new_item'           => __( 'New Collection' ),
    'all_items'          => __( 'All Collection' ),
    'view_item'          => __( 'View Collection' ),
    'search_items'       => __( 'Search Collection' ),
    'not_found'          => __( 'No Collection found' ),
    'not_found_in_trash' => __( 'No Collection found in the Trash' ), 
    'parent_item_colon'  => '',
    'menu_name'          => 'Coleccion'
  );
  $args = array(
    'labels'        => $labels,
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
    'has_archive'   => true,
  );
  register_post_type( 'coleccion', $args ); 
}
add_action( 'init', 'coleccion_post' );

function taxonomies_collection() {
  $labels = array(
    'name'              => _x( 'Collection Categories', 'taxonomy general name' ),
    'singular_name'     => _x( 'Collection Category', 'taxonomy singular name' ),
    'search_items'      => __( 'Search Collection Categories' ),
    'all_items'         => __( 'All Collections Categories' ),
    'parent_item'       => __( 'Parent Collection Category' ),
    'parent_item_colon' => __( 'Parent Collection Category:' ),
    'edit_item'         => __( 'Edit Collection Category' ), 
    'update_item'       => __( 'Update Collection Category' ),
    'add_new_item'      => __( 'Add New Collection Category' ),
    'new_item_name'     => __( 'New Collection Category' ),
    'menu_name'         => __( 'Collection Categories' ),
  );
  $args = array(
    'labels' => $labels,
    'hierarchical' => true,
  );
  register_taxonomy( 'elementos', 'coleccion', $args );
}
add_action( 'init', 'taxonomies_collection', 0 );

function imagenes_coleccion(){
  add_image_size('coleccion',300,200,false);

}
add_action('after_setup_theme','imagenes_coleccion');
