<?php
/**
 * The template for displaying archive pages
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package zakra
 */

get_header();
?>
	<div id="primary" class="content-area">
		<?php echo apply_filters( 'zakra_after_primary_start_filter', false ); // WPCS: XSS OK. ?>

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
				zakra_entry_title();
				the_archive_description( '<div class="archive-description">', '</div>' );
				?>
			</header><!-- .page-header -->
            
             <p class="texto">El Museo de Ciencias Naturales del I.E.S. Padre Suárez cuenta con gran variedad de especímenes y objetos de interés, distribuidos todos ellos entre las salas
             que componen el recinto. Cada una de ellas recoge piezas clasificadas previamente en las categorías que se muestran en el plano proporcionado a continuación:</p>

            <img class="plano" width="400" height="600" src="http://www.museopadresuarez.es.mialias.net/wp-content/uploads/2020/05/plano.jpg" alt="Plano del Museo">
            
            <?php                   
			
			do_action( 'zakra_before_posts_the_loop' );
           
			/* Start the Loop */
            
            foreach(get_terms('elementos', array('hide_empty' => true)) as $tag){ 
                echo "<h1>".$tag->name."</h1>"; 
                echo '<div class="contenido" id="'.$tag->name.'">';
			    while ( have_posts() ) :  the_post();                            
				        $argumentos=array(
                            'post_type' => 'coleccion',
                            'posts_per_page' => -1,
                            'elementos' => $tag->name,
                            'orderby' => 'date',
                            'order' => 'DESC',
                        );
                        $objetos = new WP_Query($argumentos);                   
                endwhile;
                 
                
                do_action( 'zakra_after_posts_the_loop' );                    
                    while($objetos->have_posts()) : $objetos->the_post(); ?>                    
                        <div class="card" onclick="location.href='<?php the_permalink(); ?>';">                      
                        <?php if ( get_field( 'image') ) { ?>
                        <img src="<?php the_field( 'image' ); ?>" />
                        <?php } ?>
                        <?php the_title('<h4>','</h4>'); ?>                  
                        </div>
                    <?php endwhile; wp_reset_postdata(); ?>
                    </div>
            <?php } ?>                        
		<?php else :

			get_template_part( 'content-coleccion', 'none' );

		endif;
		?>

		<?php echo apply_filters( 'zakra_after_primary_end_filter', false ); // // WPCS: XSS OK. ?>
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();
						