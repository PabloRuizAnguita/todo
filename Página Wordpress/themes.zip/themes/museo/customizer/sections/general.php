<?php

function academia_customizer_define_general_sections( $sections ) {
    $panel           = 'academia' . '_general';
    $general_sections = array();

    $theme_sidebar_positions = array(
        'both'     => esc_html__('Both', 'museo'),
        'left'      => esc_html__('Left', 'museo'),
        'right'     => esc_html__('Right', 'museo'),
        'none'    => esc_html__('None', 'museo')
    );

    $general_sections['general'] = array(
        'title'     => esc_html__( 'Theme Settings', 'museo' ),
        'priority'  => 4900,
        'options'   => array(

            'theme-sidebar-position'    => array(
                'setting'               => array(
                    'default'           => 'both',
                    'sanitize_callback' => 'academia_sanitize_text'
                ),
                'control'           => array(
                    'label'         => esc_html__( 'Default Layout', 'museo' ),
                    'type'          => 'select',
                    'choices'       => $theme_sidebar_positions
                ),
            ),

            'theme-museo-display-pages'    => array(
                'setting'               => array(
                    'sanitize_callback' => 'absint',
                    'default'           => '1'
                ),
                'control'               => array(
                    'label'             => __( 'Display Featured Pages on Homepage', 'museo' ),
                    'type'              => 'checkbox'
                )
            ),

            'theme-museo-featured-page-1'  => array(
                'setting'               => array(
                    'default'           => 'none',
                    'sanitize_callback' => 'museo_sanitize_pages'
                ),
                'control'               => array(
                    'label'             => esc_html__( 'Featured Page #1', 'museo' ),
                    'description'       => sprintf( wp_kses( __( 'This list is populated with <a href="%1$s">Pages</a>.', 'museo' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'edit.php?post_type=page' ) ) ),
                    'type'              => 'select',
                    'choices'           => museo_get_pages()
                ),
            ),

            'theme-museo-featured-page-2'  => array(
                'setting'               => array(
                    'default'           => 'none',
                    'sanitize_callback' => 'museo_sanitize_pages'
                ),
                'control'               => array(
                    'label'             => esc_html__( 'Featured Page #2', 'museo' ),
                    'type'              => 'select',
                    'choices'           => museo_get_pages()
                ),
            ),

            'theme-museo-featured-page-3'  => array(
                'setting'               => array(
                    'default'           => 'none',
                    'sanitize_callback' => 'museo_sanitize_pages'
                ),
                'control'               => array(
                    'label'             => esc_html__( 'Featured Page #3', 'museo' ),
                    'type'              => 'select',
                    'choices'           => museo_get_pages()
                ),
            ),

        ),
    );

    return array_merge( $sections, $general_sections );
}

add_filter( 'academia_customizer_sections', 'academia_customizer_define_general_sections' );
